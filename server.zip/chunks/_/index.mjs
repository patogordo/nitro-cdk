import { SQSClient, SendMessageCommand, ReceiveMessageCommand, DeleteMessageCommand, DeleteMessageBatchCommand } from '@aws-sdk/client-sqs';

const sqsClient = new SQSClient({
  // region: process.env.AWS_SQS_REGION,
  // credentials: {
  //   accountId: process.env.AWS_SQS_ACCOUNT_ID,
  //   accessKeyId: process.env.AWS_SQS_ACCESS_KEY_ID,
  //   secretAccessKey: process.env.AWS_SQS_SECRET_ACCESS_KEY,
  // },
  useQueueUrlAsEndpoint: false
});
const produce = async (queue, data) => {
  await sqsClient.send(
    new SendMessageCommand({
      QueueUrl: queue,
      MessageBody: JSON.stringify(data)
    })
  );
};
const consume = async (queue) => {
  const messages = await sqsClient.send(
    new ReceiveMessageCommand({
      QueueUrl: queue,
      WaitTimeSeconds: 0.5
    })
  );
  return (messages == null ? void 0 : messages.Messages) || [];
};
const acknowledge = async (queue, message) => {
  await sqsClient.send(
    new DeleteMessageCommand({
      QueueUrl: queue,
      ReceiptHandle: message.ReceiptHandle
    })
  );
};
const batchAcknowledge = async (queue, messages) => {
  if (!messages.length) {
    return;
  }
  await sqsClient.send(
    new DeleteMessageBatchCommand({
      QueueUrl: queue,
      Entries: messages.map((m) => ({
        Id: m.MessageId,
        ReceiptHandle: m.ReceiptHandle
      }))
    })
  );
};
const awsMessagingAdapter = {
  produce,
  consume,
  acknowledge,
  batchAcknowledge
};

const messaging = awsMessagingAdapter;

export { messaging as m };
//# sourceMappingURL=index.mjs.map
