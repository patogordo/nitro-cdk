import { d as defineEventHandler } from '../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';

const index = defineEventHandler(() => {
  return { ok: true };
});

export { index as default };
//# sourceMappingURL=index.mjs.map
