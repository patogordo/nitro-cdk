import { d as defineEventHandler } from '../../../../nitro/nitro.mjs';
import { m as messaging } from '../../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import '@aws-sdk/client-sqs';

const consume_get = defineEventHandler(async () => {
  const startTime = Date.now();
  const messages = await messaging.consume("patoqueue");
  await messaging.batchAcknowledge("patoqueue", messages);
  const endTime = Date.now();
  return {
    time: endTime - startTime,
    messages
  };
});

export { consume_get as default };
//# sourceMappingURL=consume.get.mjs.map
