import { d as defineEventHandler } from '../../../../nitro/nitro.mjs';
import { m as messaging } from '../../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import '@aws-sdk/client-sqs';

const produce_get = defineEventHandler(async () => {
  const startTime = Date.now();
  await messaging.produce("patoqueue", {
    hello: "world"
  });
  const endTime = Date.now();
  return {
    time: endTime - startTime,
    ok: true
  };
});

export { produce_get as default };
//# sourceMappingURL=produce.get.mjs.map
