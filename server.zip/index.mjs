import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};export { h as handler } from './chunks/nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
//# sourceMappingURL=index.mjs.map
